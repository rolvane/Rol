
const help = (prefix) => { 
	return `               


                       COMANDOS
╠══════════════════════
║                       ADEMIRS
║╭─────────────────────
║├> ${prefix}welcome [0/1]
║├> ${prefix}bv [0/1]
║├> ${prefix}bemvindo [0/1]
║├> ${prefix}boasvindas [0/1]
║├────> desativar/ativa bv
║├─────────────────────
║├> ${prefix}add 55xxx
║├> ${prefix}adicionar 55xxx
║├────> add menbro
║├─────────────────────
║├> ${prefix}kick @membro
║├> ${prefix}ban @membro
║├> ${prefix}remover @membro
║├────> remover membro
║├─────────────────────
║├> ${prefix}promote @membro
║├> ${prefix}promover @membro
║├────> promover a ADM
║├─────────────────────
║├> ${prefix}demote @adm
║├> ${prefix}promover @adm
║├────> rebaixar a membro
║├─────────────────────
║├> ${prefix}grup abrir/fechar
║├> ${prefix}group abrir/fechar
║├> ${prefix}grupo abrir/fechar
║├────> bem específico ;-;
║├─────────────────────
║├> ${prefix}setname seu txt
║├> ${prefix}mudarnome seu txt
║├────> troca nome do grupo
║├─────────────────────
║├> ${prefix}setdesc seu txt
║├> ${prefix}mudardesc seu txt
║├────> troca descrição
║├─────────────────────
║├> ${prefix}mudarfoto
║├────> mudar foto do grupo
║├─────────────────────
║├> ${prefix}marcar
║├────> marcação
║├─────────────────────
║├> ${prefix}marcar2
║├────> marcação 2
║├─────────────────────
║├> ${prefix}marcar3
║├────> marcação
║├─────────────────────
║├> BAIXAR/ᏞᏆΝᏦ
║├─────────────────────
║├> ${prefix}tiktokstalk Nick da conta
║├────> stalk de tiktok
║├─────────────────────
║├> ${prefix}fototiktok
║├────> foto do tiktok
║├─────────────────────
║├> ${prefix}ytmp4 link
║├> ${prefix}ytvideo link
║├> ${prefix}ytbuscar link
║├> ${prefix}ytbaixa link
║├────> baixa vídeo do YouTube
║├─────────────────────
║               ᎷᏆᎠᏆᎪ/ϴႮͲᎡϴՏ
║├─────────────────────
║├> ${prefix}sticker
║├> ${prefix}stiker
║├> ${prefix}fig
║├> ${prefix}figurinha
║├────> fazer fig cm foto/gif
║├─────────────────────
║├> ${prefix}tts seu txt
║├> ${prefix}gtts seu txt
║├> ${prefix}audio seu txt
║├────> converter txt em áudio
║├─────────────────────
║├> ${prefix}toimg marca fig
║├> ${prefix}converter marca fig
║├────> converter fig em foto
║├─────────────────────
║├> ${prefix}txtdafoto
║├> ${prefix}ocr
║├────> pega txt de foto
║├─────────────────────
║├> ${prefix}wait marca foto
║├> ${prefix}pesquisar marca foto
║├────> pesquisa por anime de ft
║├─────────────────────
║├> ${prefix}listaadms
║├> ${prefix}listadmins
║├> ${prefix}adms
║├────> lista dos adms
║├─────────────────────
║├> ${prefix}cachorro
║├> ${prefix}auau
║├> ${prefix}dog
║├────> dog fofo aleatório
║├─────────────────────
║├> ${prefix}pokemon
║├────> pokemon aleatório
║├─────────────────────
║├> ${prefix}logo3d seu txt
║├────> logo cm seu texto
║├─────────────────────
║├> ${prefix}logoph seu|txt
║├────> logo cm seu texto
║├─────────────────────
║├> ${prefix}info
║├────> informações do bot
║├─────────────────────
║├> ${prefix}listabloq
║├────> números bloqueados
║├─────────────────────
║├> ${prefix}lofi
║├────> foto única de lofi
║├─────────────────────
║├> ${prefix}map 0000-0000 
║├> ${prefix} ${prefix}mapa 0000-0000 
║├────> pega foto do local
║├─────────────────────
║            EXCLUSIVO DO DONO
║├─────────────────────
║├> ${prefix}hidetag
║├────> esconde tag
║├─────────────────────
║├> ${prefix}clearall
║├> ${prefix}limpar
║├────> limpa zap do bot
║├─────────────────────
║├> ${prefix}bloquear @membro
║├────> autobloq
║├─────────────────────
║├> ${prefix}desbloquear
║├────> autodesbloq
║├─────────────────────
║├> ${prefix}kitar
║├────> bot sai fo grupo
║├─────────────────────
║├> ${prefix}bc
║├────> [?] 
║├─────────────────────
║├> ${prefix}clonar
║├> ${prefix}clone
║├────> clonar tag
║├─────────────────────
║├>  ՏႮᏢϴᎡͲᎬ
║├─────────────────────
║├> ${prefix}bug
║├> ${prefix}reportar
║├> ${prefix}reportarbug
║├────> reportar bug ao criador
║├─────────────────────
║├> ${prefix}sigla nova sigla
║├> ${prefix}setprefix
║├────> troca sigla de comandos
║└─────────────────────
`
}
exports.help = help



  
