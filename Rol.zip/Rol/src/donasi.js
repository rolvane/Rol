const donasi = () => {
	return `

┏━━━━━━━━━━━━━━━━━━━━
┃          nao da pra doar pro Rolvane
┣━━━━━━━━━━━━━━━━━━━━

`
}

exports.donasi = donasi
